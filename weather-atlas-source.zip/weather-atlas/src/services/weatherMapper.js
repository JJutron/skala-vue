export const WEATHER_TYPES = ['Clear', 'Rain', 'Snow', 'Wind', 'Clouds', 'Fog']

export const getWeatherType = (data) => {
  if (!data) return 'Clouds'

  const id = data.weather?.[0]?.id ?? 0
  const wind = data.wind?.speed ?? 0

  if (id >= 200 && id < 600) return 'Rain'
  if (id >= 600 && id < 700) return 'Snow'
  if (id >= 700 && id < 800) return 'Fog'
  if (id === 800) return wind >= 8 ? 'Wind' : 'Clear'
  if (id > 800) return wind >= 10 ? 'Wind' : 'Clouds'
  return wind >= 8 ? 'Wind' : 'Clouds'
}

export const normalizeWeather = (region, data) => {
  if (!data) return null

  return {
    regionId: region.id,
    name: region.name,
    english: region.english,
    temp: Math.round(data.main.temp),
    feelsLike: Math.round(data.main.feels_like),
    humidity: data.main.humidity,
    wind: Number(data.wind?.speed ?? 0),
    clouds: data.clouds?.all ?? 0,
    precipitation: data.rain?.['1h'] ?? data.snow?.['1h'] ?? 0,
    condition: data.weather?.[0]?.description ?? '',
    conditionMain: data.weather?.[0]?.main ?? '',
    type: getWeatherType(data),
    raw: data,
  }
}
