<script setup>
import { computed } from 'vue'

const props = defineProps({
  region: { type: Object, required: true },
  weatherType: { type: String, default: 'Clouds' },
  active: { type: Boolean, default: false },
  dimmed: { type: Boolean, default: false },
})

const emit = defineEmits(['enter', 'leave', 'select'])

const fill = computed(() => `url(#wash-${props.weatherType.toLowerCase()})`)
</script>

<template>
  <g
    class="region"
    :class="{ active, dimmed }"
    :data-region="region.id"
    tabindex="0"
    role="button"
    :aria-label="`${region.fullName || region.name} 날씨 보기`"
    @pointerdown="emit('enter', region.id)"
    @mouseenter="emit('enter', region.id)"
    @mouseleave="emit('leave', region.id)"
    @click="emit('select', region.id)"
    @keydown.enter.prevent="emit('select', region.id)"
    @keydown.space.prevent="emit('select', region.id)"
  >
    <path
      v-for="(d, index) in region.paths"
      :key="`${region.id}-${index}`"
      class="land"
      :d="d"
      :fill="fill"
    />
    <text
      :x="region.label.x"
      :y="region.label.y"
      class="label"
      :class="region.kind"
      text-anchor="middle"
      dy="0.35em"
    >
      {{ region.name }}
    </text>
  </g>
</template>

<style scoped>
.region {
  cursor: pointer;
}

.region.dimmed {
  opacity: 0.32;
}

.land {
  stroke: var(--moon);
  stroke-width: 1.35;
  stroke-linejoin: round;
  stroke-linecap: round;
  fill-opacity: 0;
  vector-effect: non-scaling-stroke;
  transition:
    stroke var(--duration-feedback) var(--ease-out-cubic),
    stroke-width var(--duration-feedback) var(--ease-out-cubic);
}

.region.active .land,
.region:focus-visible .land {
  stroke: var(--hanji);
  stroke-width: 2.1;
  filter: url(#glow);
}

.region:active .land {
  stroke-width: 2.4;
}

.label {
  fill: var(--hanji);
  font-family: var(--sans);
  font-size: 14px;
  font-weight: 600;
  letter-spacing: 0.06em;
  paint-order: stroke;
  stroke: var(--sumi);
  stroke-width: 2px;
  pointer-events: none;
  opacity: 0;
}

.label.metro {
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.04em;
  stroke-width: 1.75px;
}
</style>
