<script setup>
import { computed, nextTick, onMounted, ref } from 'vue'
import { storeToRefs } from 'pinia'
import { koreaViewBox, regions } from '../../data/regions.js'
import { useWeatherStore } from '../../stores/weatherStore.js'
import { useWeatherAnimation } from '../../composables/useWeatherAnimation.js'
import MapRegion from './MapRegion.vue'
import RegionTooltip from './RegionTooltip.vue'
import WeatherParticles from '../weather/WeatherParticles.vue'

const store = useWeatherStore()
const { hoveredRegionId, selectedRegionId, weatherByRegion, hoveredRegion, hoveredWeather } =
  storeToRefs(store)
const { drawMap, hoverRegion, leaveRegion, reduced } = useWeatherAnimation()
const mapRoot = ref(null)
const drawn = ref(false)
const tooltip = ref({ x: 0, y: 0 })

const weatherTypeOf = (id) => weatherByRegion.value[id]?.type ?? 'Clouds'

const regionEl = (id) => mapRoot.value?.querySelector(`[data-region="${id}"]`)

const onEnter = (id) => {
  store.hoverRegion(id)
  hoverRegion(regionEl(id))
}

const onMove = (event) => {
  const bounds = mapRoot.value?.getBoundingClientRect()
  if (!bounds) return
  const x = event.clientX - bounds.left + 18
  const y = event.clientY - bounds.top - 10
  tooltip.value = {
    x: Math.min(Math.max(8, x), Math.max(8, bounds.width - 208)),
    y: Math.min(Math.max(8, y), Math.max(8, bounds.height - 128)),
  }
}

const onLeave = (id) => {
  if (hoveredRegionId.value === id) store.hoverRegion(null)
  leaveRegion(
    regionEl(id),
    Boolean(selectedRegionId.value) && selectedRegionId.value !== id,
  )
}

onMounted(async () => {
  await nextTick()
  const lands = [...(mapRoot.value?.querySelectorAll('.land') ?? [])]
  const majors = lands.filter((el) => (el.getTotalLength?.() ?? 0) > 72)
  const specks = lands.filter((el) => (el.getTotalLength?.() ?? 0) <= 72)
  const labels = [...(mapRoot.value?.querySelectorAll('.label') ?? [])]
  drawMap({ majors, specks, labels })
  drawn.value = reduced()
  window.setTimeout(() => {
    drawn.value = true
  }, reduced() ? 0 : 2100)
})

const showTip = computed(
  () => Boolean(hoveredRegion.value) && hoveredRegionId.value !== selectedRegionId.value,
)
</script>

<template>
  <div ref="mapRoot" class="map-stage" :class="{ drawn }" @mousemove="onMove">
    <WeatherParticles
      class="map-weather"
      :type="hoveredWeather?.type || 'Clouds'"
      :intensity="0.38"
    />
    <!-- Coastline geometry: Simplemaps.com, free for commercial use -->
    <svg class="korea" :viewBox="koreaViewBox" role="img" aria-label="대한민국 날씨 지도">
      <defs>
        <filter id="glow">
          <feDropShadow dx="0" dy="10" stdDeviation="8" flood-color="var(--moon)" flood-opacity="0.42" />
        </filter>
        <linearGradient id="wash-clear" x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stop-color="#4a5644" />
          <stop offset="100%" stop-color="#c45c48" />
        </linearGradient>
        <linearGradient id="wash-rain" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#2a241c" />
          <stop offset="100%" stop-color="#8a8378" />
        </linearGradient>
        <linearGradient id="wash-snow" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#2a241c" />
          <stop offset="100%" stop-color="#b7aea0" />
        </linearGradient>
        <linearGradient id="wash-wind" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#3a443c" />
          <stop offset="100%" stop-color="#7a9a86" />
        </linearGradient>
        <linearGradient id="wash-clouds" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#2a241c" />
          <stop offset="100%" stop-color="#b7aea0" />
        </linearGradient>
        <linearGradient id="wash-fog" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#2a241c" />
          <stop offset="100%" stop-color="#f4ead7" />
        </linearGradient>
      </defs>
      <MapRegion
        v-for="region in regions"
        :key="region.id"
        :region="region"
        :weather-type="weatherTypeOf(region.id)"
        :active="selectedRegionId === region.id || hoveredRegionId === region.id"
        :dimmed="Boolean(selectedRegionId) && selectedRegionId !== region.id"
        @enter="onEnter"
        @leave="onLeave"
        @select="store.selectRegion"
      />
    </svg>
    <RegionTooltip
      v-if="showTip"
      class="float-tip"
      :style="{ left: tooltip.x + 'px', top: tooltip.y + 'px' }"
      :region="hoveredRegion"
      :weather="hoveredWeather"
    />
    <p class="credit">해안선 Simplemaps</p>
  </div>
</template>

<style scoped>
.map-stage {
  position: relative;
  min-height: min(78vh, 760px);
}

.korea {
  width: min(100%, 680px);
  height: auto;
  display: block;
  margin: 0 auto;
  overflow: visible;
  filter: drop-shadow(0 28px 48px rgba(0, 0, 0, 0.42));
}

.map-weather {
  position: absolute;
  inset: 4% 12% 10%;
  pointer-events: none;
  color: var(--moon);
}

.float-tip {
  position: absolute;
  z-index: 3;
}

.credit {
  margin: 2px 0 0;
  text-align: center;
  color: var(--mist);
  opacity: 0.7;
  font-size: 0.72rem;
}

.map-stage.drawn :deep(.land) {
  fill-opacity: 1;
}

.map-stage.drawn :deep(.label) {
  opacity: 1;
}
</style>
