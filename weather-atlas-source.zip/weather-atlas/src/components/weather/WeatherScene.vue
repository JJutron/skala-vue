<script setup>
import { computed } from 'vue'
import WeatherParticles from './WeatherParticles.vue'

const props = defineProps({
  region: { type: Object, default: null },
  weather: { type: Object, default: null },
})

const type = computed(() => props.weather?.type ?? 'Clouds')
const motif = computed(() => props.region?.motif ?? 'plain')
</script>

<template>
  <div v-if="region" class="scene" :data-type="type" :data-motif="motif">
    <WeatherParticles :type="type" :intensity="0.55" />
    <svg class="drawing" viewBox="0 0 280 160" aria-hidden="true">
      <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
        <g v-if="motif === 'ridge'" opacity="0.9">
          <path d="M8 138 L54 86 L92 118 L138 48 L176 96 L228 36 L272 132" stroke-width="1.5" />
          <path d="M8 138 L272 132" stroke-width="1.1" opacity="0.45" />
        </g>
        <g v-else-if="motif === 'sea' || motif === 'coast'" opacity="0.9">
          <path d="M16 92c42 18 76-14 118 6 40 18 78 2 130 16" stroke-width="1.35" />
          <path d="M28 118c38 10 82-8 124 6 36 12 72 4 108 10" stroke-width="1.1" opacity="0.45" />
        </g>
        <g v-else-if="motif === 'island'" opacity="0.9">
          <path d="M86 118c18-38 92-38 110 0 8 16-12 28-54 28s-64-12-56-28z" stroke-width="1.35" />
          <path d="M48 136c58 10 128 10 184 0" stroke-width="1" opacity="0.4" />
        </g>
        <g v-else opacity="0.9">
          <path d="M18 124 C78 108 132 128 262 112" stroke-width="1.3" />
          <path d="M40 138 C110 126 170 142 250 128" stroke-width="1" opacity="0.4" />
        </g>
        <circle
          v-if="type === 'Clear'"
          cx="214"
          cy="40"
          r="15"
          stroke="var(--cinnabar)"
          stroke-width="1.6"
        />
        <circle
          v-else-if="type === 'Snow' || type === 'Fog'"
          cx="214"
          cy="40"
          r="11"
          stroke="currentColor"
          stroke-width="1.2"
          opacity="0.55"
        />
      </g>
    </svg>
  </div>
</template>

<style scoped>
.scene {
  position: relative;
  height: 148px;
  overflow: hidden;
  margin-top: 16px;
  background: color-mix(in srgb, var(--hanji) 88%, var(--sumi));
  color: var(--on-paper);
}

.drawing {
  position: relative;
  z-index: 1;
  width: 100%;
  height: 100%;
}
</style>
